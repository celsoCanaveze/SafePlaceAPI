using SavePlaceAPIV2.Models;
using SavePlaceAPIV2.Repository;
using SavePlaceAPIV2.Repository.Interfaces;
using SavePlaceAPIV2.Services.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SavePlaceAPIV2.Services
{
    public class UsuarioService : IUsuarioService
    {
        private readonly IUsuarioRepository _repo;

        public UsuarioService(IUsuarioRepository repo)
        {
            _repo = repo;
        }

        public Task<List<Usuario>> ListarAsync() => _repo.GetAllAsync();
        public Task<Usuario?> BuscarPorIdAsync(int id) => _repo.GetByIdAsync(id);
        public Task<Usuario> CriarAsync(Usuario usuario) => _repo.AddAsync(usuario);
        public Task<Usuario?> AtualizarAsync(Usuario usuario) => _repo.UpdateAsync(usuario);
        public Task<bool> DeletarAsync(int id) => _repo.DeleteAsync(id);
        public Task<Usuario?> BuscarPorEmailAsync(string email) => _repo.GetByEmailAsync(email);
    }
}
