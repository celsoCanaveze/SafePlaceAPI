using SavePlaceAPIV2.Models;
using SavePlaceAPIV2.Repository.Interfaces;
using SavePlaceAPIV2.Services.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SavePlaceAPIV2.Services
{
    public class AbrigoService : IAbrigoService
    {
        private readonly IAbrigoRepository _repo;

        public AbrigoService(IAbrigoRepository repo)
        {
            _repo = repo;
        }

        public Task<List<Abrigo>> ListarAsync() => _repo.GetAllAsync();
        public Task<Abrigo?> BuscarPorIdAsync(int id) => _repo.GetByIdAsync(id);
        public Task<Abrigo> CriarAsync(Abrigo abrigo) => _repo.AddAsync(abrigo);
        public Task<Abrigo?> AtualizarAsync(Abrigo abrigo) => _repo.UpdateAsync(abrigo);
        public Task<bool> DeletarAsync(int id) => _repo.DeleteAsync(id);
    }
}
