﻿using SavePlaceAPIV2.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SavePlaceAPIV2.Services.Interfaces
{
    public interface IAbrigoService
    {
        Task<List<Abrigo>> ListarAsync();
        Task<Abrigo?> BuscarPorIdAsync(int id);
        Task<Abrigo> CriarAsync(Abrigo abrigo);
        Task<Abrigo?> AtualizarAsync(Abrigo abrigo);
        Task<bool> DeletarAsync(int id);
    }
}
