﻿using SavePlaceAPIV2.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SavePlaceAPIV2.Services.Interfaces
{
    public interface IAlertaService
    {
        Task<List<Alerta>> ListarAsync();
        Task<Alerta?> BuscarPorIdAsync(int id);
        Task<Alerta> CriarAsync(Alerta alerta);
        Task<Alerta?> AtualizarAsync(Alerta alerta);
        Task<bool> DeletarAsync(int id);
    }
}
