﻿using SavePlaceAPIV2.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SavePlaceAPIV2.Services.Interfaces
{
    public interface IUsuarioService
    {
        Task<List<Usuario>> ListarAsync();
        Task<Usuario?> BuscarPorIdAsync(int id);
        Task<Usuario> CriarAsync(Usuario usuario);
        Task<Usuario?> AtualizarAsync(Usuario usuario);
        Task<bool> DeletarAsync(int id);
        Task<Usuario?> BuscarPorEmailAsync(string email);
    }
}
