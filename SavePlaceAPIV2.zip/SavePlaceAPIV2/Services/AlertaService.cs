using SavePlaceAPIV2.Models;
using SavePlaceAPIV2.Repository.Interfaces;
using SavePlaceAPIV2.Services.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SavePlaceAPIV2.Services
{
    public class AlertaService : IAlertaService
    {
        private readonly IAlertaRepository _repo;

        public AlertaService(IAlertaRepository repo)
        {
            _repo = repo;
        }

        public Task<List<Alerta>> ListarAsync() => _repo.GetAllAsync();
        public Task<Alerta?> BuscarPorIdAsync(int id) => _repo.GetByIdAsync(id);
        public Task<Alerta> CriarAsync(Alerta alerta) => _repo.AddAsync(alerta);
        public Task<Alerta?> AtualizarAsync(Alerta alerta) => _repo.UpdateAsync(alerta);
        public Task<bool> DeletarAsync(int id) => _repo.DeleteAsync(id);
    }
}
