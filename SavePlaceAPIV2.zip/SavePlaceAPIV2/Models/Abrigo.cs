using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
#nullable enable

namespace SavePlaceAPIV2.Models
{
    [Table("ABRIGOS")]
    public class Abrigo
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("ID")]
        public int Id { get; set; }

        [Column("NOME")]
        [Required, MaxLength(150)]
        public string Nome { get; set; } = string.Empty;

        [Column("ENDERECO")]
        [Required, MaxLength(200)]
        public string Endereco { get; set; } = string.Empty;

        [Column("CAPACIDADE")]
        [Required]
        public int Capacidade { get; set; }

        [Column("OCUPACAO_ATUAL")]
        public int OcupacaoAtual { get; set; }

        [Column("CONTATO")]
        [MaxLength(100)]
        public string? Contato { get; set; }

        public ICollection<Usuario> Usuarios { get; set; } = new List<Usuario>();

        public ICollection<Alerta> Alertas { get; set; } = new List<Alerta>();
    }
}
