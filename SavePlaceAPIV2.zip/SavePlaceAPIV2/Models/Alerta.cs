using SavePlaceAPIV2.Models;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

[Table("ALERTAS")]
public class Alerta
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    [Column("ID")]
    public int Id { get; set; }

    [Column("TIPO")]
    [Required, MaxLength(100)]
    public string Tipo { get; set; } = string.Empty;

    [Column("DESCRICAO")]
    [Required, MaxLength(500)]
    public string Descricao { get; set; } = string.Empty;

    [Column("DATA_HORA")]
    [Required]
    public DateTime DataHora { get; set; }

    [Column("ABRIGO_ID")]
    public int AbrigoId { get; set; }

    [ForeignKey("AbrigoId")]
    public Abrigo? Abrigo { get; set; }
}
