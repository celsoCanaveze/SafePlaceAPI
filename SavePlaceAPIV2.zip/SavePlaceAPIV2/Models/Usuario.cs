using SavePlaceAPIV2.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

[Table("USUARIOS")]
public class Usuario
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    [Column("ID")]
    public int Id { get; set; }

    [Column("NOME")]
    [Required, MaxLength(100)]
    public string Nome { get; set; } = string.Empty;

    [Column("EMAIL")]
    [Required, EmailAddress, MaxLength(100)]
    public string Email { get; set; } = string.Empty;

    [Column("TELEFONE")]
    [MaxLength(100)]
    public string? Telefone { get; set; }

    [Column("SENHA")]
    [Required, MaxLength(100)]
    public string Senha { get; set; } = string.Empty;

    [Column("ABRIGO_ID")]
    public int AbrigoId { get; set; }

    [ForeignKey("AbrigoId")]
    public Abrigo? Abrigo { get; set; }
}
