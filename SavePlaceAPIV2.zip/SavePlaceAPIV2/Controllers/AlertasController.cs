using Microsoft.AspNetCore.Mvc;
using SavePlaceAPIV2.Models;
using SavePlaceAPIV2.Repository.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SavePlaceAPIV2.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AlertasController : ControllerBase
    {
        private readonly IAlertaRepository _repository;

        public AlertasController(IAlertaRepository repository)
        {
            _repository = repository;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Alerta>>> GetAll() =>
            Ok(await _repository.GetAllAsync());

        [HttpGet("{id}")]
        public async Task<ActionResult<Alerta>> Get(int id)
        {
            var alerta = await _repository.GetByIdAsync(id);
            if (alerta == null) return NotFound();
            return Ok(alerta);
        }

        [HttpPost]
        public async Task<ActionResult<Alerta>> Post([FromBody] Alerta alerta)
        {
            var novo = await _repository.AddAsync(alerta);
            return CreatedAtAction(nameof(Get), new { id = novo.Id }, novo);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> Put(int id, [FromBody] Alerta alerta)
        {
            if (id != alerta.Id) return BadRequest();

            var atualizado = await _repository.UpdateAsync(alerta);
            if (atualizado == null) return NotFound();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            var ok = await _repository.DeleteAsync(id);
            if (!ok) return NotFound();
            return NoContent();
        }
    }
}
