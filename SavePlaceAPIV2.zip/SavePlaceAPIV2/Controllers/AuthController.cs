﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using SavePlaceAPIV2.Models;
using SavePlaceAPIV2.DTOs;
using SavePlaceAPIV2.Data;
using System;
using System.Linq;
using Microsoft.Extensions.Configuration;





[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly IConfiguration _config;
    private readonly AppDbContext _context;

    public AuthController(IConfiguration config, AppDbContext context)
    {
        _config = config;
        _context = context;
    }

    [HttpPost("login")]
    public IActionResult Login([FromBody] LoginDTO login)
    {
        var user = _context.Usuarios.FirstOrDefault(u => u.Email == login.Email);
        if (user == null || !BCrypt.Net.BCrypt.Verify(login.Senha, user.Senha))
            return Unauthorized("Usuário ou senha inválidos.");

        var token = GenerateToken(user);
        return Ok(new { token });
    }

    [HttpPost("register")]
    public IActionResult Register([FromBody] UsuarioDTO usuarioDto)
    {
        if (_context.Usuarios.Any(u => u.Email == usuarioDto.Email))
            return BadRequest("Email já está em uso.");

        var usuario = new Usuario
        {
            Nome = usuarioDto.Nome,
            Email = usuarioDto.Email,
            Senha = BCrypt.Net.BCrypt.HashPassword(usuarioDto.Senha)
        };

        _context.Usuarios.Add(usuario);
        _context.SaveChanges();

        return Ok(new { message = "Usuário registrado com sucesso." });
    }

    private string GenerateToken(Usuario user)
    {
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var claims = new[]
        {
            new Claim(ClaimTypes.Name, user.Email),
            new Claim("Id", user.Id.ToString())
        };

        var token = new JwtSecurityToken(
            issuer: _config["Jwt:Issuer"],
            audience: _config["Jwt:Audience"],
            claims: claims,
            expires: DateTime.Now.AddHours(2),
            signingCredentials: creds
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}
