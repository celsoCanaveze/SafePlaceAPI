using Microsoft.AspNetCore.Mvc;
using SavePlaceAPIV2.Models;
using SavePlaceAPIV2.Repository.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SavePlaceAPIV2.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AbrigosController : ControllerBase
    {
        private readonly IAbrigoRepository _repository;

        public AbrigosController(IAbrigoRepository repository)
        {
            _repository = repository;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Abrigo>>> GetAll() =>
            Ok(await _repository.GetAllAsync());

        [HttpGet("{id}")]
        public async Task<ActionResult<Abrigo>> Get(int id)
        {
            var abrigo = await _repository.GetByIdAsync(id);
            if (abrigo == null) return NotFound();
            return Ok(abrigo);
        }

        [HttpPost]
        public async Task<ActionResult<Abrigo>> Post([FromBody] Abrigo abrigo)
        {
            var novo = await _repository.AddAsync(abrigo);
            return CreatedAtAction(nameof(Get), new { id = novo.Id }, novo);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> Put(int id, [FromBody] Abrigo abrigo)
        {
            if (id != abrigo.Id) return BadRequest();

            var atualizado = await _repository.UpdateAsync(abrigo);
            if (atualizado == null) return NotFound();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            var ok = await _repository.DeleteAsync(id);
            if (!ok) return NotFound();
            return NoContent();
        }
    }
}
