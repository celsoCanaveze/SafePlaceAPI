using Microsoft.EntityFrameworkCore;
using SavePlaceAPIV2.Models;

namespace SavePlaceAPIV2.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options) { }

        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Abrigo> Abrigos { get; set; }
        public DbSet<Alerta> Alertas { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Relacionamento Abrigo -> Usuarios
            modelBuilder.Entity<Abrigo>()
                .HasMany(a => a.Usuarios)
                .WithOne(u => u.Abrigo)
                .HasForeignKey(u => u.AbrigoId)
                .OnDelete(DeleteBehavior.Cascade);

            // Relacionamento Abrigo -> Alertas
            modelBuilder.Entity<Abrigo>()
                .HasMany(a => a.Alertas)
                .WithOne(al => al.Abrigo)
                .HasForeignKey(al => al.AbrigoId)
                .OnDelete(DeleteBehavior.Cascade);

        }
    }
}
