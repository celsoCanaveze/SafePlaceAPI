using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using SavePlaceAPIV2.Data;
using SavePlaceAPIV2.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SavePlaceAPIV2.Pages.Admin
{
    public class IndexModel : PageModel
    {
        private readonly AppDbContext _context;

        public IndexModel(AppDbContext context)
        {
            _context = context;
        }

        public List<Abrigo> Abrigos { get; set; }

        public async Task OnGetAsync()
        {
            Abrigos = await _context.Abrigos.Include(a => a.Usuarios).ToListAsync();
        }
    }
}
