using Microsoft.EntityFrameworkCore;
using SavePlaceAPIV2.Data;
using SavePlaceAPIV2.Models;
using SavePlaceAPIV2.Repository.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SavePlaceAPIV2.Repository
{
    public class AbrigoRepository : IAbrigoRepository
    {
        private readonly AppDbContext _context;

        public AbrigoRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Abrigo>> GetAllAsync() => await _context.Abrigos.ToListAsync();

        public async Task<Abrigo?> GetByIdAsync(int id) => await _context.Abrigos.FindAsync(id);

        public async Task<Abrigo> AddAsync(Abrigo abrigo)
        {
            _context.Abrigos.Add(abrigo);
            await _context.SaveChangesAsync();
            return abrigo;
        }

        public async Task<Abrigo?> UpdateAsync(Abrigo abrigo)
        {
            var existente = await _context.Abrigos.FindAsync(abrigo.Id);
            if (existente == null) return null;

            _context.Entry(existente).CurrentValues.SetValues(abrigo);
            await _context.SaveChangesAsync();
            return existente;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var abrigo = await _context.Abrigos.FindAsync(id);
            if (abrigo == null) return false;

            _context.Abrigos.Remove(abrigo);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
