using Microsoft.EntityFrameworkCore;
using SavePlaceAPIV2.Data;
using SavePlaceAPIV2.Models;
using SavePlaceAPIV2.Repository.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SavePlaceAPIV2.Repository
{
    public class AlertaRepository : IAlertaRepository
    {
        private readonly AppDbContext _context;

        public AlertaRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Alerta>> GetAllAsync() => await _context.Alertas.ToListAsync();

        public async Task<Alerta?> GetByIdAsync(int id) => await _context.Alertas.FindAsync(id);

        public async Task<Alerta> AddAsync(Alerta alerta)
        {
            _context.Alertas.Add(alerta);
            await _context.SaveChangesAsync();
            return alerta;
        }

        public async Task<Alerta?> UpdateAsync(Alerta alerta)
        {
            var existente = await _context.Alertas.FindAsync(alerta.Id);
            if (existente == null) return null;

            _context.Entry(existente).CurrentValues.SetValues(alerta);
            await _context.SaveChangesAsync();
            return existente;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var alerta = await _context.Alertas.FindAsync(id);
            if (alerta == null) return false;

            _context.Alertas.Remove(alerta);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
