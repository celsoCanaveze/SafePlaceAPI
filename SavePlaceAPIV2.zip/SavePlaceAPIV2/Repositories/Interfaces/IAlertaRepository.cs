﻿using SavePlaceAPIV2.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SavePlaceAPIV2.Repository.Interfaces
{
    public interface IAlertaRepository
    {
        Task<List<Alerta>> GetAllAsync();
        Task<Alerta?> GetByIdAsync(int id);
        Task<Alerta> AddAsync(Alerta alerta);
        Task<Alerta?> UpdateAsync(Alerta alerta);
        Task<bool> DeleteAsync(int id);
    }
}
