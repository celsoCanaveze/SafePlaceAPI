﻿using SavePlaceAPIV2.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SavePlaceAPIV2.Repository.Interfaces
{
    public interface IAbrigoRepository
    {
        Task<List<Abrigo>> GetAllAsync();
        Task<Abrigo?> GetByIdAsync(int id);
        Task<Abrigo> AddAsync(Abrigo abrigo);
        Task<Abrigo?> UpdateAsync(Abrigo abrigo);
        Task<bool> DeleteAsync(int id);
    }
}
