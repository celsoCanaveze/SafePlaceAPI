// Serviço de geração e validação de JWT
